#For the results of Gaussian fitting
import matplotlib.pyplot as plt
import numpy as np
import math
import FFunction
def main():
    # 1.getting data
    conInfo = FFunction.readFile(input('Please type the filename(example: Part of zircon U-Pb database of China.csv):'))

    # 2.getting the fitting results
    choseAge, choseAgeN, lon, lat = FFunction.simpleData(conInfo, 1452.25, 2859.34)
    peakList, sigmaList, weightList=FFunction.gaussianS(choseAge)
    print('peak:',peakList)
    print('sigma:',sigmaList)
    print('weight:',weightList)
    # 3.drawing
    plt.figure()
    plt.hist(choseAge,density=1,bins=300,color="darksalmon")
    length_choseAge=len(choseAge)
    print('length_choseAge',length_choseAge)
    for i in range(len(peakList)):
        x = np.linspace(peakList[i] - 3 * sigmaList[i], peakList[i] + 3 * sigmaList[i], 100)
        y_sig = weightList[i]*(np.exp(-(x - peakList[i]) ** 2 / (2 * sigmaList[i] ** 2)) / (math.sqrt(2 * math.pi) * sigmaList[i]))
        plt.plot(x, y_sig, "r-", color='darkblue',linewidth=1)

    plt.rcParams['font.sans-serif'] = ['Times New Roman'] # setting font
    plt.rcParams['axes.unicode_minus'] = False  # to show minus
    plt.text(3000,0.005,'total data records:124 425',bbox=dict(facecolor='white',edgecolor='black',alpha=1))
    plt.xlabel("age/Ma")
    plt.ylabel("frequency")
    plt.show()

if __name__=='__main__':
    main()