These codes were written by Xianjun Fang.
There are five code files.
FFunction.py provides necessary functions for the rest four code files.
F01Gaussian_fitting.py is to get results of Gaussian fitting.
F02Real_crustal_growth_event_distribution.py is to obtain real spatial distribution of every crustal growth event.
F03Crustal_units_sameOrSimilar_evolution.py is  to get crustal units based on "same evolution" and "similar evolution" criteria.
F04Final_crustal_units.py is to show spatial distribution map of every crustal growth event based on “similar crustal evolution” criterion, comparison between spatial distributions of crustal growth events based on “similar crustal evolution” criterion and crustal units.

The needed python packages include numpy, matplotlib, sklearn, basemap.

'gadm36_CHN_1', which show the state boundaries of China, are files from https://gadm.org/index.html.
'Country' and 'coastline', which show the national boundaries of the World, are files provided by Lei Zhang, one of co-writers.
A csv file is needed to put in the same directory to run those codes and its format should be as same as the dataset we provided.

