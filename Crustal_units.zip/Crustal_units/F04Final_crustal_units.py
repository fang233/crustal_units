# There are three functions to use.
# The first is single_cluser() which is to draw spatial distribution map of every crustal growth event based on “similar crustal evolution” criterion
# The second is cluster_overlap() which is to show comparison between spatial distributions of crustal growth events based on “similar crustal evolution” criterion
# The third is finalCrustalUnits() which is to show crustal units
import math
import numpy as np
import matplotlib.pyplot as plt
import FFunction
from mpl_toolkits.basemap import Basemap
import copy
import matplotlib.colors as colors
def similarBackground(x,y,com_gridCluster_result,grid_numberList,no_age_gridList,gridPeakNumberSim,peak_combinationList,require_len):
    # final_draw represents the different peak combinations of basic grids; final_drawNumber represents the clusters of basic grids
    final_draw = [-1 for i in range(x * y)]
    final_drawNumber = [-1 for i in range(x * y)]

    need_to_change_grids = []
    not_peakCom_index = []
    final_peakCom_indexs = []
    final_drawNumber_clusters = []
    final_peakCom_numbers = []
    peakCom_count = 1

    for every_peakCom_index in range(len(com_gridCluster_result)):
        # if this peak combination contains clusters
        if len(com_gridCluster_result[every_peakCom_index]) != 0:
            # to judge whether clusters are qualified
            judge = False
            for every_cluster in com_gridCluster_result[every_peakCom_index]:
                if len(every_cluster) >= require_len:
                    judge = True
                    break
            # if at least one cluster is qualified,final_draw will remember this cluster and its corresponding peak combination
            if judge:
                final_peakCom_indexs.append(every_peakCom_index)
                peakCom_cluster_count = 0
                for every_cluster in com_gridCluster_result[every_peakCom_index]:
                    if len(every_cluster) >= require_len:
                        #print('qualified clusters:', every_cluster)
                        cluster_number = peakCom_count * 10 + peakCom_cluster_count
                        final_drawNumber_clusters.append(every_cluster)
                        final_peakCom_numbers.append(cluster_number)
                        for every_grid in every_cluster:
                            final_draw[every_grid] = peakCom_count
                            final_drawNumber[every_grid] = cluster_number
                        peakCom_cluster_count += 1
                    else:  # grids belonging to unqualified clusters need to be changed
                        for every_grid in every_cluster:
                            need_to_change_grids.append(every_grid)
                peakCom_count += 1
            else:
                not_peakCom_index.append(every_peakCom_index)
                for every_cluster in com_gridCluster_result[every_peakCom_index]:
                    for every_grid in every_cluster:
                        need_to_change_grids.append(every_grid)

    # To adjust the peak combinations of unqualified grids
    need_to_change_grids_copy = need_to_change_grids[:]
    # grids which are hard to be clustered
    difficult_judge_grids = []
    while len(need_to_change_grids_copy) != 0:
        gridNumber = need_to_change_grids_copy[0]
        round_gridNumber = [gridNumber - x, gridNumber + x, gridNumber - 1, gridNumber + 1, gridNumber - x - 1,
                            gridNumber + x + 1, gridNumber - x + 1, gridNumber + x - 1]
        # round_grid_counts represents the number of grids which are adjacent to central grid
        round_grid_counts = 0
        for rounds in round_gridNumber:
            if rounds in grid_numberList:
                round_grid_counts += 1
        # To judge the situation of adjacent grids
        no_age_counts = 0
        belong_cluster_grids = []
        belong_change_grids = []

        for rounds in round_gridNumber:
            # this adjacent grid has no age data
            if rounds in no_age_gridList:
                no_age_counts += 1
            # this adjacent grid belongs to grids of which peak combination need to change
            elif rounds in need_to_change_grids:
                belong_change_grids.append(rounds)
            # this adjacent grid is qualified
            elif (rounds not in need_to_change_grids) and rounds < x * y:
                belong_cluster_grids.append(rounds)

        # this central grid is surrounded by grids without data
        if no_age_counts == round_grid_counts:
            need_to_change_grids_copy.pop(0)
            final_draw[gridNumber] = 0
        # there at least one adjacent grid with age data
        elif len(belong_cluster_grids) != 0:
            select_peakCom_index, select_roundGrid = FFunction.compareSimilar(gridNumber, belong_cluster_grids,
                                                                    gridPeakNumberSim, peak_combinationList)
            gridPeakNumberSim[gridNumber] = select_peakCom_index
            final_draw[gridNumber] = final_draw[select_roundGrid]
            final_drawNumber[gridNumber] = final_drawNumber[select_roundGrid]
            final_drawNumber_clusters[final_peakCom_numbers.index(final_drawNumber[gridNumber])].append(gridNumber)
            need_to_change_grids_copy.pop(0)
            need_to_change_grids.pop(need_to_change_grids.index(gridNumber))
        else:
            if difficult_judge_grids.count(gridNumber) == 10:
                final_draw[gridNumber] = 0
                need_to_change_grids_copy.pop(0)
            else:
                select_peakCom_index, select_roundGrid = FFunction.compareSimilar(gridNumber, belong_change_grids,
                                                                        gridPeakNumberSim, peak_combinationList)
                gridPeakNumberSim[gridNumber] = select_peakCom_index
                need_to_change_grids_copy.pop(0)
                need_to_change_grids_copy.append(gridNumber)
                difficult_judge_grids.append(gridNumber)

    return final_draw,final_drawNumber,final_peakCom_indexs,peakCom_count
def single_cluster():
    # 1.getting data
    conInfo = FFunction.readFile(input('Please type the filename(example: Part of zircon U-Pb database of China.csv):'))

    choseAge, choseAgeN, lon, lat = FFunction.simpleData(conInfo, 1452.25, 2859.34)
    number = len(choseAge)
    # 2.setting the range of latitude, longitude, and the scale of grid
    # EM means the extreme east, WM means the extreme west, SM means the extreme south, and NM means extreme north
    # x represents the number of grids along longitude while y represents the number of grids along latitude
    EM, WM, SM, NM = 140, 70, 16, 55
    interval = float(input('Please type the basic grid you want to use(example: 1):'))
    x, y = math.ceil((EM - WM) / interval), math.ceil((NM - SM) / interval)
    # the required number of basic grids for every qualified continental crustal units
    require_len = 2
    # 3.putting ages into the grids that they belong to
    grid_conAge = [[] for i in range(x * y)]
    grid_numberList = [i for i in range(x * y)]
    for i in range(number):
        try:
            count = int((float(lon[i]) - WM) // interval) + (int(float((lat[i]) - SM) // interval)) * x
            grid_conAge[count].append(choseAge[i])
        except:
            continue

    # 4.no_age_gridList collects grids without data
    no_age_gridList = []
    for every_grid in range(len(grid_conAge)):
        if len(grid_conAge[every_grid]) == 0:
            no_age_gridList.append(every_grid)
    # 5. getting the peak combinations of every basic grid
    peakList = [45.47191501721, 132.02488348912564, 249.07083787994625, 440.8688987552644, 814.99252896288,
                1235.5880341203751, 1908.2750689880334, 2505.1741828979793, 2932.733387973]
    sigmaList = [23.50208485387001, 22.11961839983983, 47.74288173121555, 48.247783434211065, 91.98571575449814,
                 190.4293589626058, 152.2596776296344, 90.00529650075231, 378.0092872606897]
    peak_count = len(peakList)
    # getting simplified peak combinations of basic grids
    gridPeakNumberSim, peak_combinationList = FFunction.peakComSimInGrid(grid_conAge, peakList, sigmaList, 2)
    # getting clusters
    com_gridCluster_result = FFunction.peakComGridCluster(gridPeakNumberSim, grid_numberList, peak_count, x)
    # 6. choosing rules of clustering similar
    final_draw, final_drawNumber, final_peakCom_indexs, peakCom_count = similarBackground(x, y, com_gridCluster_result,
                                                                                          grid_numberList,
                                                                                          no_age_gridList,
                                                                                          gridPeakNumberSim,
                                                                                          peak_combinationList,
                                                                                          require_len)
    # 7. "0" represents grids without data
    for grid in no_age_gridList:
        final_draw[grid] = 0
    # ------------------------------------------
    part_peakComList = []
    for i in final_peakCom_indexs:
        part_peakComList.append(peak_combinationList[i])
    peak45, peak132, peak249, peak441, peak815, peak1236, peak1908, peak2505, peak2933 = [], [], [], [], [], [], [], [], []
    collect_peaks = [peak45, peak132, peak249, peak441, peak815, peak1236, peak1908, peak2505, peak2933]
    collect_names = ['peak45', 'peak132', 'peak249', 'peak441', 'peak815', 'peak1236', 'peak1908', 'peak2505',
                     'peak2933']
    for i in range(len(part_peakComList)):
        for j in part_peakComList[i]:
            collect_peaks[j].append(i + 1)

    final_drawNumber_set = list(set(final_drawNumber))
    try:
        final_drawNumber_set.remove(0)
        final_drawNumber_set.remove(-1)
    except:
        pass
    final_drawNumber_set.sort()
    final_drawNumber_cluster = [[] for i in range(len(final_drawNumber_set))]
    for i_index in range(len(final_drawNumber)):
        for drawNumber_index in range(len(final_drawNumber_set)):
            if final_drawNumber[i_index] == final_drawNumber_set[drawNumber_index]:
                final_drawNumber_cluster[drawNumber_index].append(i_index)

    # spatial distribution of every crustal growth events
    final_draw = np.array(final_draw).reshape(y, x)
    for collect in range(len(collect_peaks)):
        temSim = [0 for i in range(x * y)]
        temSim = np.array(temSim).reshape(y, x)
        for j in range(y):
            for k in range(x):
                if final_draw[j][k] in collect_peaks[collect]:
                    temSim[j][k] = 1

        fig = plt.figure(figsize=(30.0, 16.0))
        ax = fig.add_subplot(111)
        extent = ax.get_window_extent().transformed(fig.dpi_scale_trans.inverted())
        m = Basemap(llcrnrlon=70, urcrnrlon=140, llcrnrlat=15, urcrnrlat=55)
        m.drawcoastlines()
        m.drawcountries()
        parallels = np.arange(15., 55, 10.)
        m.drawparallels(parallels, labels=[False, True, True, False])
        meridians = np.arange(70., 140., 10.)
        m.drawmeridians(meridians, labels=[True, False, False, True])
        m.readshapefile('gadm36_CHN_1', 'states',drawbounds=True, color='grey', linewidth=0.5)
        plt.rcParams['font.sans-serif'] = ['Times New Roman']
        plt.rcParams['axes.unicode_minus'] = False
        lons = np.linspace(WM, WM + x * interval, x + 1)
        lats = np.linspace(SM, SM + y * interval, y + 1)
        lon, lat = np.meshgrid(lons, lats)
        Ax, Ay = m(lon, lat)
        m.pcolor(Ax, Ay, temSim, cmap=FFunction.colormap0(2))
        # If you want to save figures, please use this code
        #plt.savefig('Cluster' + str(internal) + collect_names[collect] + '.png', bbox_inches=extent)
        plt.show()
        #plt.close()
def cluster_overlap():
    # 1.getting data
    conInfo = FFunction.readFile(input('Please type the filename(example: Part of zircon U-Pb database of China.csv):'))

    choseAge, choseAgeN, lon, lat = FFunction.simpleData(conInfo, 1452.25, 2859.34)
    number = len(choseAge)
    # 2.setting the range of latitude, longitude, and the scale of grid
    # EM means the extreme east, WM means the extreme west, SM means the extreme south, and NM means extreme north
    # x represents the number of grids along longitude while y represents the number of grids along latitude
    EM, WM, SM, NM = 140, 70, 16, 55
    interval = float(input('Please type the basic grid you want to use(example: 1):'))
    x, y = math.ceil((EM - WM) / interval), math.ceil((NM - SM) / interval)
    # the required number of basic grids for every qualified continental crustal units
    require_len = 2
    # 3.putting ages into the grids that they belong to
    grid_conAge = [[] for i in range(x * y)]
    grid_numberList = [i for i in range(x * y)]
    for i in range(number):
        try:
            count = int((float(lon[i]) - WM) // interval) + (int(float((lat[i]) - SM) // interval)) * x
            grid_conAge[count].append(choseAge[i])
        except:
            continue
    # 4.no_age_gridList collects grids without data
    no_age_gridList = []
    for every_grid in range(len(grid_conAge)):
        if len(grid_conAge[every_grid]) == 0:
            no_age_gridList.append(every_grid)
    # 5. getting the peak combinations of every basic grid
    peakList = [45.47191501721, 132.02488348912564, 249.07083787994625, 440.8688987552644, 814.99252896288,
                1235.5880341203751, 1908.2750689880334, 2505.1741828979793, 2932.733387973]
    sigmaList = [23.50208485387001, 22.11961839983983, 47.74288173121555, 48.247783434211065, 91.98571575449814,
                 190.4293589626058, 152.2596776296344, 90.00529650075231, 378.0092872606897]
    peak_count = len(peakList)
    # getting simplified peak combinations of basic grids
    gridPeakNumberSim, peak_combinationList = FFunction.peakComSimInGrid(grid_conAge, peakList, sigmaList, 2)
    # getting clusters
    com_gridCluster_result = FFunction.peakComGridCluster(gridPeakNumberSim, grid_numberList, peak_count, x)
    # 6. choosing rules of clustering similar
    final_draw, final_drawNumber, final_peakCom_indexs, peakCom_count = similarBackground(x, y, com_gridCluster_result,
                                                                                          grid_numberList,
                                                                                          no_age_gridList,
                                                                                          gridPeakNumberSim,
                                                                                          peak_combinationList,
                                                                                          require_len)
    # 7. "0" represents grids without data
    for grid in no_age_gridList:
        final_draw[grid] = 0

    # ------------------------------------------
    part_peakComList = []
    for i in final_peakCom_indexs:
        part_peakComList.append(peak_combinationList[i])
    print(part_peakComList)
    peak45, peak132, peak249, peak441, peak815, peak1236, peak1908, peak2505, peak2933 = [], [], [], [], [], [], [], [], []
    collect_peaks = [peak45, peak132, peak249, peak441, peak815, peak1236, peak1908, peak2505, peak2933]
    collect_names = ['45Ma', '132Ma', '249Ma', '441Ma', '815Ma', '1236Ma', '1908Ma', '2505Ma',
                     '2933Ma']
    for i in range(len(part_peakComList)):
        for j in part_peakComList[i]:
            collect_peaks[j].append(i + 1)

    final_drawNumber_set = list(set(final_drawNumber))
    try:
        final_drawNumber_set.remove(0)
        final_drawNumber_set.remove(-1)
    except:
        pass
    final_drawNumber_set.sort()
    # final_drawNumber_cluster放每个cluster的index
    final_drawNumber_cluster = [[] for i in range(len(final_drawNumber_set))]
    for i_index in range(len(final_drawNumber)):
        for drawNumber_index in range(len(final_drawNumber_set)):
            if final_drawNumber[i_index] == final_drawNumber_set[drawNumber_index]:
                final_drawNumber_cluster[drawNumber_index].append(i_index)

    # draw figures
    final_draw=np.array(final_draw).reshape(y,x)
    for peak_index in range(0,len(collect_peaks)-1,2):

        temSim = [0 for i in range(x * y)]
        temSim = np.array(temSim).reshape(y, x)
        for j in range(y):
            for k in range(x):
                if (final_draw[j][k] in collect_peaks[peak_index]) and (final_draw[j][k] in collect_peaks[peak_index+1]):
                    temSim[j][k] = 2
                elif final_draw[j][k] in collect_peaks[peak_index]:
                    temSim[j][k] = 1
                elif final_draw[j][k] in collect_peaks[peak_index+1]:
                    temSim[j][k] = 3
        fig = plt.figure(figsize=(30.0, 16.0))
        ax = fig.add_subplot(111)
        extent = ax.get_window_extent().transformed(fig.dpi_scale_trans.inverted())
        m = Basemap(llcrnrlon=70, urcrnrlon=140, llcrnrlat=15, urcrnrlat=55)
        m.drawcoastlines()
        m.drawcountries()
        parallels = np.arange(15., 55, 10.)
        m.drawparallels(parallels, labels=[False, True, True, False])
        meridians = np.arange(70., 140., 10.)
        m.drawmeridians(meridians, labels=[True, False, False, True])
        m.readshapefile('gadm36_CHN_1', 'states',drawbounds=True, color='grey', linewidth=0.5)
        plt.rcParams['font.sans-serif'] = ['Times New Roman']
        plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
        plt.rcParams['font.size'] = 15
        lons = np.linspace(WM, WM + x * interval, x + 1)
        lats = np.linspace(SM, SM + y * interval, y + 1)
        lon, lat = np.meshgrid(lons, lats)
        Ax, Ay = m(lon, lat)
        temcolors = colors.ListedColormap(['w', 'dodgerblue', 'olive', 'orange'], 'indexed')
        datamap = m.pcolor(Ax, Ay, temSim, cmap=temcolors)
        cb = plt.colorbar(datamap, cmap=temcolors, ticks=[i for i in range(4)])
        labels = ['other', collect_names[peak_index], collect_names[peak_index]+'&'+collect_names[peak_index+1], collect_names[peak_index+1]]
        cb.set_ticklabels(labels, update_ticks=True)
        # If you want to save figures, please use this code
        #plt.savefig('NewOverlap' + str(interval) +collect_names[peak_index]+collect_names[peak_index+1]+'.png', bbox_inches=extent)
        plt.show()
        #plt.close()

def finalCrustalUnits():
    # 1.getting data
    conInfo = FFunction.readFile(input('Please type the filename(example: Part of zircon U-Pb database of China.csv):'))

    choseAge, choseAgeN, lon, lat = FFunction.simpleData(conInfo, 1452.25, 2859.34)
    number = len(choseAge)

    # 2.setting the range of latitude, longitude, and the scale of grid
    # EM means the extreme east, WM means the extreme west, SM means the extreme south, and NM means extreme north
    # x represents the number of grids along longitude while y represents the number of grids along latitude
    EM, WM, SM, NM = 140, 70, 16, 55
    interval = float(input('Please type the basic grid you want to use(example: 1):'))
    x, y = math.ceil((EM - WM) / interval), math.ceil((NM - SM) / interval)
    # the required number of basic grids for every qualified continental crustal units
    require_len = 2
    # 3.putting ages into the grids that they belong to
    grid_conAge = [[] for i in range(x * y)]
    grid_numberList = [i for i in range(x * y)]
    for i in range(number):
        try:
            count = int((float(lon[i]) - WM) // interval) + (int(float((lat[i]) - SM) // interval)) * x
            grid_conAge[count].append(choseAge[i])
        except:
            continue

    # 4.no_age_gridList collects grids without data
    no_age_gridList = []
    for every_grid in range(len(grid_conAge)):
        if len(grid_conAge[every_grid]) == 0:
            no_age_gridList.append(every_grid)

    # 5. getting the peak combinations of every basic grid
    peakList = [45.47191501721, 132.02488348912564, 249.07083787994625, 440.8688987552644, 814.99252896288,
                1235.5880341203751, 1908.2750689880334, 2505.1741828979793, 2932.733387973]
    sigmaList = [23.50208485387001, 22.11961839983983, 47.74288173121555, 48.247783434211065, 91.98571575449814,
                 190.4293589626058, 152.2596776296344, 90.00529650075231, 378.0092872606897]
    peak_count = len(peakList)
    # getting simplified peak combinations of basic grids
    gridPeakNumberSim, peak_combinationList = FFunction.peakComSimInGrid(grid_conAge, peakList, sigmaList, 2)

    # getting clusters
    com_gridCluster_result = FFunction.peakComGridCluster(gridPeakNumberSim, grid_numberList, peak_count, x)

    # 6. choosing rules of clustering similar
    final_draw,final_drawNumber,final_peakCom_indexs,peakCom_count=similarBackground(x,y,com_gridCluster_result,grid_numberList,no_age_gridList,gridPeakNumberSim,peak_combinationList,require_len)

    # 7. "0" represents grids without data
    for grid in no_age_gridList:
        final_draw[grid] = 0

    #------------------------------------------
    part_peakComList=[]
    for i in final_peakCom_indexs:
        part_peakComList.append(peak_combinationList[i])
    print(part_peakComList)
    peak45,peak132,peak249,peak441,peak815,peak1236,peak1908,peak2505,peak2933=[],[],[],[],[],[],[],[],[]
    collect_peaks = [peak45,peak132,peak249,peak441,peak815,peak1236,peak1908,peak2505,peak2933]
    for i in range(len(part_peakComList)):
        for j in part_peakComList[i]:
            collect_peaks[j].append(i+1)

    final_drawNumber_set=list(set(final_drawNumber))
    try:
        final_drawNumber_set.remove(0)
        final_drawNumber_set.remove(-1)
    except:
        pass
    final_drawNumber_set.sort()

    final_drawNumber_cluster=[[] for i in range(len(final_drawNumber_set))]
    for i_index in range(len(final_drawNumber)):
        for drawNumber_index in range(len(final_drawNumber_set)):
            if final_drawNumber[i_index]==final_drawNumber_set[drawNumber_index]:
                final_drawNumber_cluster[drawNumber_index].append(i_index)
    final_draw_intergrate=[0 for i in range(x*y)]

    peak249_441=list(set(peak249+peak441))
    peak815_1236 = list(set(peak815 + peak1236))
    peak1908_2505_2933 = list(set(peak1908 + peak2505+peak2933))

    #Rules
    for grid_index in range(x*y):
        # Rule 1
        if (final_draw[grid_index] in peak45):
            final_draw_intergrate[grid_index]=1
        # Rule 2
        elif (final_draw[grid_index] in peak132) and (final_draw[grid_index] not in peak815_1236) and (final_draw[grid_index] not in peak1908_2505_2933):
            final_draw_intergrate[grid_index]=2
        # Rule 3
        elif (final_draw[grid_index] in peak249_441) and (final_draw[grid_index] not in peak815_1236) and (
                    final_draw[grid_index] not in peak1908_2505_2933):
            final_draw_intergrate[grid_index] = 3
        # Rule 4
        elif (final_draw[grid_index] in peak132) and (final_draw[grid_index] in peak815_1236):
            final_draw_intergrate[grid_index] = 4
        # Rule 5
        elif (final_draw[grid_index] not in peak132) and (final_draw[grid_index] in peak815_1236):
            final_draw_intergrate[grid_index] = 5
        # Rule 6
        elif (final_draw[grid_index] not in peak815_1236) and (final_draw[grid_index] in peak1908_2505_2933):
            final_draw_intergrate[grid_index] = 6



    final_integrate_cluster=[[] for i in range(6)]
    for gridNumber in range(x*y):
        if final_draw_intergrate[gridNumber]!=0:
            putin=False
            round_gridNumber = [gridNumber - x, gridNumber + x, gridNumber - 1, gridNumber + 1, gridNumber - x - 1,
                                gridNumber + x + 1, gridNumber - x + 1, gridNumber + x - 1]
            tem_index=final_draw_intergrate[gridNumber]-1
            for round_grid in round_gridNumber:
                for tem_cluster_index in range(len(final_integrate_cluster[tem_index])):
                    if round_grid in final_integrate_cluster[tem_index][tem_cluster_index]:
                        final_integrate_cluster[tem_index][tem_cluster_index].append(gridNumber)
                        putin=True
                        break
                if putin:
                    break
            if putin==False:
                final_integrate_cluster[tem_index].append([gridNumber])



    final_integrate_cluster_f=[[] for i in range(len(final_integrate_cluster))]
    final_integrate_cluster_arround=copy.deepcopy(final_integrate_cluster)
    for cluster_index in range(len(final_integrate_cluster)):
        for licluster_index in range(len(final_integrate_cluster[cluster_index])):
            for gridNumber in final_integrate_cluster[cluster_index][licluster_index]:
                round_gridNumber = [gridNumber - x, gridNumber + x, gridNumber - 1, gridNumber + 1, gridNumber - x - 1,
                                gridNumber + x + 1, gridNumber - x + 1, gridNumber + x - 1]
                for round_grid in round_gridNumber:
                    if round_grid not in final_integrate_cluster_arround[cluster_index][licluster_index]:
                        final_integrate_cluster_arround[cluster_index][licluster_index].append(round_grid)


    for cluster_index in range(len(final_integrate_cluster_arround)):

        while len(final_integrate_cluster_arround[cluster_index])>1:

            gether=False
            for licluster_index in range(1,len(final_integrate_cluster_arround[cluster_index])):
                if len(list(set(final_integrate_cluster_arround[cluster_index][0]) & set(final_integrate_cluster_arround[cluster_index][licluster_index])))>0:

                    final_integrate_cluster_arround[cluster_index][0]+=final_integrate_cluster_arround[cluster_index][licluster_index]
                    final_integrate_cluster_arround[cluster_index].pop(licluster_index)
                    final_integrate_cluster[cluster_index][0] += final_integrate_cluster[cluster_index][licluster_index]
                    final_integrate_cluster[cluster_index].pop(licluster_index)
                    gether=True
                    break
            if len(final_integrate_cluster_arround[cluster_index])==1:
                final_integrate_cluster_f[cluster_index].append(final_integrate_cluster[cluster_index][0])
            if gether==False:

                final_integrate_cluster_f[cluster_index].append(final_integrate_cluster[cluster_index][0])
                final_integrate_cluster_arround[cluster_index].pop(0)
                final_integrate_cluster[cluster_index].pop(0)
                if len(final_integrate_cluster_arround[cluster_index])==1:
                    final_integrate_cluster_f[cluster_index].append(final_integrate_cluster[cluster_index][0])

    final_draw_integrate_adjust = [0 for i in range(x * y)]
    final_cluster_count = 0
    for cluster_index in range(len(final_integrate_cluster_f)):
        for licluster_index in range(len(final_integrate_cluster_f[cluster_index])):
            final_cluster_count += 1
            for gridNumber in final_integrate_cluster_f[cluster_index][licluster_index]:
                final_draw_integrate_adjust[gridNumber] = final_cluster_count

    del final_integrate_cluster_arround

    # To recluster those units whose grids are less than threshold
    threshold = 21
    final_integrate_cluster_f_low=[]
    for i in final_integrate_cluster_f:
        final_integrate_cluster_f_low+=i
    #
    final_integrate_cluster_f_lens = [0]
    for i in final_integrate_cluster_f_low:
        final_integrate_cluster_f_lens.append(len(i))
    final_integrate_cluster_f_lens_index = [i for i in range(len(final_integrate_cluster_f_lens))]
    final_integrate_cluster_arround = copy.deepcopy(final_integrate_cluster_f_low)
    for cluster_index in range(len(final_integrate_cluster_f_low)):
        for gridNumber in final_integrate_cluster_f_low[cluster_index]:
            round_gridNumber = [gridNumber - x, gridNumber + x, gridNumber - 1, gridNumber + 1, gridNumber - x - 1,
                            gridNumber + x + 1, gridNumber - x + 1, gridNumber + x - 1]
            for round_grid in round_gridNumber:
                if round_grid not in final_integrate_cluster_arround[cluster_index]:
                    final_integrate_cluster_arround[cluster_index].append(round_grid)

    cluster_index=0
    total_proccess=len(final_integrate_cluster_f_low)*2
    proccess=0
    while cluster_index<len(final_integrate_cluster_f_low):
        if len(final_integrate_cluster_f_low[cluster_index])>=threshold:
            cluster_index+=1
        elif len(final_integrate_cluster_f_low[cluster_index])<threshold:
            record_best=[0 for i in range(final_cluster_count+1)]
            test_around=list(set(final_integrate_cluster_arround[cluster_index]) - set(final_integrate_cluster_f_low[cluster_index]))
            for i in test_around:
                try:
                    record_best[final_draw_integrate_adjust[i]]+=1
                except:
                    continue
            if len(set(record_best))==2:
                best=0
                for lo in final_integrate_cluster_f_low[cluster_index]:
                    final_draw_integrate_adjust[lo] = best
                    final_integrate_cluster_f_lens[best] += 1
                    final_integrate_cluster_f_lens[cluster_index] -= 1
                cluster_index = cluster_index + 1
            else:
                best=record_best.index(np.max(record_best[1:]))
                if final_integrate_cluster_f_lens[final_integrate_cluster_f_lens_index.index(best)]<threshold:
                    if proccess<=total_proccess:
                        final_integrate_cluster_f_low.append(final_integrate_cluster_f_low[cluster_index])
                        final_integrate_cluster_f_low.pop(cluster_index)
                        final_integrate_cluster_f_lens.append(final_integrate_cluster_f_lens[cluster_index])
                        final_integrate_cluster_f_lens.pop(cluster_index)
                        final_integrate_cluster_f_lens_index.append(final_integrate_cluster_f_lens_index[cluster_index])
                        final_integrate_cluster_f_lens_index.pop(cluster_index)
                        final_integrate_cluster_arround.append(final_integrate_cluster_arround[cluster_index])
                        final_integrate_cluster_arround.pop(cluster_index)
                        proccess+=1
                    else:
                        for lo in final_integrate_cluster_f_low[cluster_index]:
                            final_draw_integrate_adjust[lo] = 0
                            final_integrate_cluster_f_lens[cluster_index] -= 1
                        cluster_index = cluster_index + 1
                else:
                    for lo in final_integrate_cluster_f_low[cluster_index]:
                        final_draw_integrate_adjust[lo]=best
                        final_integrate_cluster_f_lens[best]+=1
                        final_integrate_cluster_f_lens[cluster_index]-=1
                    cluster_index = cluster_index + 1
    final_cluster_number_f=list(set(final_draw_integrate_adjust))
    final_cluster_number_f.sort()
    final_cluster_count_f=[i for i in range(len(set(final_draw_integrate_adjust)))]
    for i in range(len(final_draw_integrate_adjust)):
        if final_draw_integrate_adjust!=0:
            tem_index=final_cluster_number_f.index(final_draw_integrate_adjust[i])
            final_draw_integrate_adjust[i]=final_cluster_count_f[tem_index]


    lons = np.linspace(WM, WM + x * interval, x + 1)
    lats = np.linspace(SM, SM + y * interval, y + 1)
    lon, lat = np.meshgrid(lons, lats)
    my_colors = FFunction.colormap0(len(set(final_draw_integrate_adjust)))
    final_draw_integrate_adjust = np.array(final_draw_integrate_adjust).reshape(y, x)
    # setting colorbar
    plt.rcParams['font.sans-serif'] = ['Times New Roman'] # setting font
    fig = plt.figure(figsize=(30.0, 16.0))
    ax = fig.add_subplot(111)
    extent = ax.get_window_extent().transformed(fig.dpi_scale_trans.inverted())
    m = Basemap(llcrnrlon=70, urcrnrlon=140, llcrnrlat=15, urcrnrlat=55)
    parallels = np.arange(15., 55, 10.)
    m.drawparallels(parallels, labels=[False, True, True, False])
    meridians = np.arange(70., 140., 10.)
    m.drawmeridians(meridians, labels=[True, False, False, True])
    m.readshapefile('gadm36_CHN_1', 'state', drawbounds=True, color='black', linewidth=0.5)
    m.readshapefile('Country', 'Country', drawbounds=True, color='black', linewidth=0.5)
    m.readshapefile('coastline', 'coastline', drawbounds=True, color='black', linewidth=0.5)
    # writing the index of peak combinations
    Ax, Ay = m(lon, lat)
    datamap = m.pcolor(Ax, Ay, final_draw_integrate_adjust, cmap=my_colors)
    cb = plt.colorbar(datamap, cmap=my_colors, ticks=[i for i in range(peakCom_count)])
    labels =['Without data']
    for i in range(peakCom_count-1):
        labels.append('Unit '+str(i+1))
    cb.set_ticklabels(labels, update_ticks=True)
    # If you want to save this figure, please use this code
    #plt.savefig('Crustal Units'+str(round(interval,1))+'.jpeg',bbox_inches=extent)
    plt.show()
    #plt.close()

if __name__ == '__main__':
    # You can choose one of the three functions: single_cluser(), cluster_overlap(),finalCrustalUnits()
    #single_clutser()
    #cluster_overlap()
    finalCrustalUnits()