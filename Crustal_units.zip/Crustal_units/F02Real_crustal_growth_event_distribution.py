#For the real distribution of every peak
import math
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
import matplotlib.colors as colors
import FFunction

# ------------------------------------------------------------------------------------

def peakDensity(WM,SM,x,y,grid_conAge,internal,peakList,sigmaList,times):
    # primary parameters for drawing
    lons = np.linspace(WM, WM + x * internal, x + 1)
    lats = np.linspace(SM, SM + y * internal, y + 1)
    lon, lat = np.meshgrid(lons, lats)

    for single_peak_index in range(len(peakList)):
        peak_grids_count=[0 for i in range(x*y)]
        peak_grids_exist=[0 for i in range(x*y)]
        for grid_index in range(x*y):
            peak_grid_count=0
            for single_age in grid_conAge[grid_index]:
                left=peakList[single_peak_index]-sigmaList[single_peak_index]*times
                right=peakList[single_peak_index]+sigmaList[single_peak_index]*times
                if left<=single_age<=right:
                    peak_grid_count+=1
            peak_grids_count[grid_index]=peak_grid_count
        for i in range(len(peak_grids_count)):
            if peak_grids_count[i]!=0:
                peak_grids_exist[i]=1
        peak_grids_exist=np.array(peak_grids_exist).reshape(y,x)

        # drawing
        fig=plt.figure(figsize=(30.0, 16.0))
        ax = fig.add_subplot(111)
        extent = ax.get_window_extent().transformed(fig.dpi_scale_trans.inverted())

        m = Basemap(llcrnrlon=70, urcrnrlon=140, llcrnrlat=15, urcrnrlat=55)
        m.drawcoastlines()
        parallels = np.arange(15., 55, 10.)
        m.drawparallels(parallels, labels=[False, True, True, False])
        meridians = np.arange(70., 140., 10.)
        m.drawmeridians(meridians, labels=[True, False, False, True])
        m.readshapefile('gadm36_CHN_1', 'province',drawbounds=True,color='black',linewidth=0.5)
        m.readshapefile('Country','Country', drawbounds=True, color='black', linewidth=0.5)
        my_color =colors.ListedColormap(['white','black'], 'indexed')
        Ax, Ay = m(lon, lat)
        m.pcolor(Ax, Ay, peak_grids_exist, cmap=my_color)
        plt.rcParams['font.sans-serif'] = ['Times New Roman'] #setting font
        plt.rcParams['axes.unicode_minus'] = False  # to show minus
        plt.title('real distribution of '+str(round(peakList[single_peak_index]))+'Ma')
        #plt.show()
        # if you want to save figures, please use the following code
        plt.savefig('Real'+'Interval' + str(internal) + 'Peak' + str('%0.2f'%peakList[single_peak_index])+'Sigma' + str('%0.2f'%sigmaList[single_peak_index])+'Times' + str(times) + 'Density.png',bbox_inches=extent)
        plt.close()
def main():
    print('This code is to show the real distributions of every peak')
    # 1.getting data
    conInfo = FFunction.readFile(input('Please type the filename(example: Part of zircon U-Pb database of China.csv):'))

    choseAge, choseAgeN, lon, lat = FFunction.simpleData(conInfo, 1452.25, 2859.34)
    number = len(choseAge)

    # 2.setting the range of latitude, longitude, and the scale of grid
    # EM means the extreme east, WM means the extreme west, SM means the extreme south, and NM means extreme north
    # x represents the number of grids along longitude while y represents the number of grids along latitude
    EM, WM, SM, NM = 140, 70, 15, 55
    interval = float(input('Please type the basic grid you want to use(example: 1):'))
    x, y = math.ceil((EM - WM) / interval), math.ceil((NM - SM) / interval)

    # 3.putting the age data into their corresponding grids
    grid_conAge = [[] for i in range(x * y)]
    for i in range(number):
        try:
            count = int((float(lon[i]) - WM) // interval) + (int(float((lat[i]) - SM) // interval)) * x
            grid_conAge[count].append(choseAge[i])
        except:
            continue

    # 4. drawing
    # Gaussian fitting results from F01Gaussian_fitting.py
    peakList = [45.47191501721, 132.02488348912564, 249.07083787994625, 440.8688987552644, 814.99252896288,
                1235.5880341203751, 1908.2750689880334, 2505.1741828979793, 2932.733387973]
    sigmaList = [23.50208485387001, 22.11961839983983, 47.74288173121555, 48.247783434211065, 91.98571575449814,
                 190.4293589626058, 152.2596776296344, 90.00529650075231, 378.0092872606897]
    times = 2
    peakDensity(WM, SM, x, y, grid_conAge, interval, peakList, sigmaList, times)



if __name__=='__main__':
    main()